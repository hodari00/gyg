(function () {
  'use strict';

  /**
   * The gygApp.toggleComponent module
   * @module gygApp.toggleComponent
   * @name ToggleComponent
   */

  angular
    .module('gygApp.toggleComponent', []);
})();
